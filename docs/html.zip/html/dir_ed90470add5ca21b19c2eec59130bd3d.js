var dir_ed90470add5ca21b19c2eec59130bd3d =
[
    [ "windows", "dir_240c6c7330cdf440f682700ae007bc1b.html", "dir_240c6c7330cdf440f682700ae007bc1b" ],
    [ "Platform.cpp", "_platform_8cpp.html", null ],
    [ "Platform.h", "_platform_8h.html", "_platform_8h" ]
];