var surface_8h =
[
    [ "Catalyst::SurfaceData", "struct_catalyst_1_1_surface_data.html", "struct_catalyst_1_1_surface_data" ],
    [ "Catalyst::ISurface", "class_catalyst_1_1_i_surface.html", "class_catalyst_1_1_i_surface" ],
    [ "CatalystPtrSurface", "surface_8h.html#a411e205138dfcaf618dbce8fbe5d3c82", null ],
    [ "CatalystSurfaceFlags", "surface_8h.html#abbe882740464284621241b0e65b8fecc", [
      [ "CATALYST_SURFACE_DEFAULT_POSITION", "surface_8h.html#abbe882740464284621241b0e65b8fecca52c3d67c227dc8f9a8a88c82aadda535", null ],
      [ "CATALYST_SURFACE_DEFAULT_DIMENSION", "surface_8h.html#abbe882740464284621241b0e65b8fecca97427ef6b6e396bd0a5d45bb23cb6ae6", null ]
    ] ]
];