var _platform_8h =
[
    [ "Catalyst::Platform", "class_catalyst_1_1_platform.html", "class_catalyst_1_1_platform" ],
    [ "initalizePlatform", "_platform_8h.html#a43172a69dca3e4030c097785180da212", null ]
];