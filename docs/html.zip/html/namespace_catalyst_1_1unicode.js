var namespace_catalyst_1_1unicode =
[
    [ "Node", "struct_catalyst_1_1unicode_1_1_node.html", "struct_catalyst_1_1unicode_1_1_node" ],
    [ "UtfAllocationSection", "struct_catalyst_1_1unicode_1_1_utf_allocation_section.html", null ],
    [ "UTF_BMP", "namespace_catalyst_1_1unicode.html#a087356691e38590b3399ff1afa41224f", null ],
    [ "UTF_SIP", "namespace_catalyst_1_1unicode.html#ae26b62eed978a42cd22a3be4e7b09fa8", null ],
    [ "UTF_SMP", "namespace_catalyst_1_1unicode.html#ade6803c62388b5c71c09d6ad67808110", null ],
    [ "UTF_SPUA_A", "namespace_catalyst_1_1unicode.html#acd794644339c21c7ab8a7a967fd66a21", null ],
    [ "UTF_SPUA_B", "namespace_catalyst_1_1unicode.html#a8fc13f8d1efe1a2da47c79a0ddf6cd6d", null ],
    [ "UTF_SSP", "namespace_catalyst_1_1unicode.html#a20b91b4459fa8c430e49b336b5609bad", null ],
    [ "UTF_TIP", "namespace_catalyst_1_1unicode.html#ab028651968a902563e893d94ca450ce1", null ],
    [ "UTF_UAP", "namespace_catalyst_1_1unicode.html#a5a087d0c062c8629780903263a3494f2", null ]
];