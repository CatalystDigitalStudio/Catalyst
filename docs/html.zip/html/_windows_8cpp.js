var _windows_8cpp =
[
    [ "createRnederer", "_windows_8cpp.html#a4ab4783b99fd43a96f08ca1e47a53772", null ],
    [ "initalizePlatform", "_windows_8cpp.html#a43172a69dca3e4030c097785180da212", null ]
];