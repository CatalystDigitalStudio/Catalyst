var class_catalyst_1_1_windows_platform =
[
    [ "createRenderer", "class_catalyst_1_1_windows_platform.html#acb94e12ce649b7f8dc32d7e531231fc1", null ],
    [ "createSurface", "class_catalyst_1_1_windows_platform.html#a6e505b92beb91f1f9342d8c893c7b4e1", null ],
    [ "getPlatformData", "class_catalyst_1_1_windows_platform.html#a665f0c52ee4568566e96ec90b433f23a", null ]
];