var class_catalyst_1_1file_1_1_j_s_o_n_multi_lang_file =
[
    [ "JSONMultiLangFile", "class_catalyst_1_1file_1_1_j_s_o_n_multi_lang_file.html#a89f3080ddba4751bcb09b7d608792cf2", null ],
    [ "~JSONMultiLangFile", "class_catalyst_1_1file_1_1_j_s_o_n_multi_lang_file.html#abfcefecaa708f178c32b584c1ff0bac9", null ],
    [ "getLanguages", "class_catalyst_1_1file_1_1_j_s_o_n_multi_lang_file.html#a84c500edc0d30c47a9aeef4dcea8ad0a", null ],
    [ "getValueByLanguage", "class_catalyst_1_1file_1_1_j_s_o_n_multi_lang_file.html#ac1ebfeda17979b57df2f1c90ef391b30", null ]
];