var searchData=
[
  ['node_0',['Node',['../struct_catalyst_1_1unicode_1_1_node.html',1,'Catalyst::unicode']]]
];
