var struct_catalyst_1_1_surface_data =
[
    [ "m_Dimension", "struct_catalyst_1_1_surface_data.html#aa37666f0b9abf49bfc8f55db63e234f5", null ],
    [ "m_Height", "struct_catalyst_1_1_surface_data.html#a281619979ac0b2011c6584ed27e0cdd7", null ],
    [ "m_Position", "struct_catalyst_1_1_surface_data.html#abc293e6cb0f5e49e96384c417071cc86", null ],
    [ "m_Title", "struct_catalyst_1_1_surface_data.html#a7ce07887c86bc2f2b89e27c085aa09a4", null ],
    [ "m_Width", "struct_catalyst_1_1_surface_data.html#af57f5c25cd76a538f7affd378e59b509", null ],
    [ "m_X", "struct_catalyst_1_1_surface_data.html#aba98d1f16ef61cc94aa5ce87c10bf179", null ],
    [ "m_Y", "struct_catalyst_1_1_surface_data.html#a7944535f5ca8ef7d8d6e94b967a1214b", null ]
];