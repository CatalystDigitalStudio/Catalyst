var class_catalyst_1_1_logger =
[
    [ "logger", "class_catalyst_1_1_logger.html#a31b09ffeb71c2593ed1ffca9dc620e84", null ]
];