var searchData=
[
  ['logging_2ecpp_0',['logging.cpp',['../logging_8cpp.html',1,'']]],
  ['logging_2eh_1',['logging.h',['../logging_8h.html',1,'']]]
];
