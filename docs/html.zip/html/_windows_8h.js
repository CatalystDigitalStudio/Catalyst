var _windows_8h =
[
    [ "Catalyst::PlatformData", "struct_catalyst_1_1_platform_data.html", null ],
    [ "Catalyst::WindowsPlatform", "class_catalyst_1_1_windows_platform.html", "class_catalyst_1_1_windows_platform" ],
    [ "WIN32_LEAN_AND_MEAN", "_windows_8h.html#ac7bef5d85e3dcd73eef56ad39ffc84a9", null ]
];