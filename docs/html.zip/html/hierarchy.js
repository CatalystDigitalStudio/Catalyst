var hierarchy =
[
    [ "Catalyst::Constant< T, Value >", "struct_catalyst_1_1_constant.html", null ],
    [ "Catalyst::csv", "class_catalyst_1_1csv.html", null ],
    [ "Catalyst::file::CSVFile", "class_catalyst_1_1file_1_1_c_s_v_file.html", null ],
    [ "Catalyst::Engine", "class_catalyst_1_1_engine.html", null ],
    [ "Catalyst::File", "struct_catalyst_1_1_file.html", null ],
    [ "Catalyst::Font", "class_catalyst_1_1_font.html", null ],
    [ "Catalyst::IBaseEvent", "class_catalyst_1_1_i_base_event.html", [
      [ "Catalyst::IEvent< TestEvent >", "class_catalyst_1_1_i_event.html", [
        [ "TestEvent", "struct_test_event.html", null ]
      ] ],
      [ "Catalyst::IEvent< T >", "class_catalyst_1_1_i_event.html", null ]
    ] ],
    [ "Catalyst::IBaseListener", "class_catalyst_1_1_i_base_listener.html", [
      [ "Catalyst::ListenerStorage< IListener< Event >, Event >", "class_catalyst_1_1_listener_storage.html", null ],
      [ "Catalyst::ListenerStorage< IListener< Event, Events... >, Event >", "class_catalyst_1_1_listener_storage.html", null ],
      [ "Catalyst::ListenerStorage< Class, Event >", "class_catalyst_1_1_listener_storage.html", null ]
    ] ],
    [ "Catalyst::IDevice", null, [
      [ "DX11Device", "class_d_x11_device.html", null ]
    ] ],
    [ "Catalyst::IFactory< Product >", "class_catalyst_1_1_i_factory.html", null ],
    [ "Catalyst::IFactoryShared< Product >", "class_catalyst_1_1_i_factory_shared.html", null ],
    [ "Catalyst::IListener< Events >", "class_catalyst_1_1_i_listener.html", null ],
    [ "Catalyst::IListener< Event >", "class_catalyst_1_1_i_listener_3_01_event_01_4.html", null ],
    [ "Catalyst::IListener< Events... >", "class_catalyst_1_1_i_listener.html", [
      [ "Catalyst::IListener< Event, Events... >", "class_catalyst_1_1_i_listener_3_01_event_00_01_events_8_8_8_01_4.html", null ]
    ] ],
    [ "Catalyst::IListener< TestEvent >", "class_catalyst_1_1_i_listener.html", [
      [ "Reactor", "class_reactor.html", null ]
    ] ],
    [ "Catalyst::Image", "class_catalyst_1_1_image.html", null ],
    [ "Catalyst::IManager< Key, Value >", "class_catalyst_1_1_i_manager.html", null ],
    [ "Catalyst::IManager< EventType, std::vector< IBaseListener * > >", "class_catalyst_1_1_i_manager.html", [
      [ "Catalyst::ListenerManager", "class_catalyst_1_1_listener_manager.html", null ]
    ] ],
    [ "Catalyst::IManager< EventType, std::vector< std::shared_ptr< IBaseEvent > > >", "class_catalyst_1_1_i_manager.html", [
      [ "Catalyst::EventManager", "class_catalyst_1_1_event_manager.html", null ]
    ] ],
    [ "Catalyst::IManagerShared< Key, Value >", "class_catalyst_1_1_i_manager_shared.html", null ],
    [ "IMultithreadable", null, [
      [ "Catalyst::IApplication", "class_catalyst_1_1_i_application.html", [
        [ "Reactor", "class_reactor.html", null ]
      ] ]
    ] ],
    [ "Catalyst::IPipeline", "class_catalyst_1_1_i_pipeline.html", [
      [ "VulkanPipeline", "class_vulkan_pipeline.html", null ]
    ] ],
    [ "Catalyst::IRenderer", "class_catalyst_1_1_i_renderer.html", [
      [ "DX11Renderer", "class_d_x11_renderer.html", null ],
      [ "VulkanRenderer", "class_vulkan_renderer.html", null ]
    ] ],
    [ "Catalyst::ISurface", "class_catalyst_1_1_i_surface.html", [
      [ "Catalyst::WindowsSurface", "class_catalyst_1_1_windows_surface.html", null ]
    ] ],
    [ "Catalyst::ISwapChain", "class_catalyst_1_1_i_swap_chain.html", null ],
    [ "Catalyst::json", "class_catalyst_1_1json.html", [
      [ "Catalyst::file::JSONMultiLangFile", "class_catalyst_1_1file_1_1_j_s_o_n_multi_lang_file.html", null ]
    ] ],
    [ "ListenerFunction", "class_listener_function.html", null ],
    [ "Catalyst::Logger", "class_catalyst_1_1_logger.html", null ],
    [ "Catalyst::unicode::Node", "struct_catalyst_1_1unicode_1_1_node.html", null ],
    [ "Catalyst::Path", "struct_catalyst_1_1_path.html", null ],
    [ "Catalyst::PipelineInformation", "struct_catalyst_1_1_pipeline_information.html", null ],
    [ "Catalyst::Platform", "class_catalyst_1_1_platform.html", [
      [ "Catalyst::WindowsPlatform", "class_catalyst_1_1_windows_platform.html", null ]
    ] ],
    [ "Catalyst::PlatformData", "struct_catalyst_1_1_platform_data.html", null ],
    [ "Catalyst::RendererInfo", "struct_catalyst_1_1_renderer_info.html", null ],
    [ "Catalyst::Scene", "class_catalyst_1_1_scene.html", [
      [ "TestScene", "struct_test_scene.html", null ]
    ] ],
    [ "Catalyst::SurfaceData", "struct_catalyst_1_1_surface_data.html", null ],
    [ "Catalyst::utf8::Utf8Byte", "struct_catalyst_1_1utf8_1_1_utf8_byte.html", null ],
    [ "Catalyst::unicode::UtfAllocationSection< lower, upper >", "struct_catalyst_1_1unicode_1_1_utf_allocation_section.html", null ],
    [ "Catalyst::Version", "struct_catalyst_1_1_version.html", null ],
    [ "VulkanImage", "struct_vulkan_image.html", null ],
    [ "Catalyst::WindowsSurfaceData", "struct_catalyst_1_1_windows_surface_data.html", null ]
];