var searchData=
[
  ['direction_0',['Direction',['../namespace_catalyst_1_1utf8.html#af98da54c11ce739c43edd4eb38541439',1,'Catalyst::utf8']]]
];
