var class_reactor =
[
    [ "Reactor", "class_reactor.html#a238368d4aa751762a4173839c689c858", null ],
    [ "~Reactor", "class_reactor.html#ac0c3e1b109c2f1e99a055df0ac3e5ee6", null ],
    [ "getRenderer", "class_reactor.html#a3e6e74d7e958066b5c4555989a7c4cd5", null ]
];