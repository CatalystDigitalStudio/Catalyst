var _d_x11_renderer_8cpp =
[
    [ "createRenderer", "_d_x11_renderer_8cpp.html#ab86fe871b35bedefd465712e1940e5ef", null ]
];