var searchData=
[
  ['flags_0',['flags',['../struct_catalyst_1_1_renderer_info.html#a33a01975cb7d2340ebce02090661c4f1',1,'Catalyst::RendererInfo']]],
  ['format_1',['format',['../struct_vulkan_image.html#ac84e9d117166fa143256a6c462f58e1d',1,'VulkanImage']]]
];
