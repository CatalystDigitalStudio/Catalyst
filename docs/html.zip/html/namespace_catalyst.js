var namespace_catalyst =
[
    [ "file", "namespace_catalyst_1_1file.html", "namespace_catalyst_1_1file" ],
    [ "internal", "namespace_catalyst_1_1internal.html", [
      [ "createSurface", "namespace_catalyst_1_1internal.html#a97390c3648a61ea4ab140347997d4d38", null ]
    ] ],
    [ "unicode", "namespace_catalyst_1_1unicode.html", "namespace_catalyst_1_1unicode" ],
    [ "utf8", "namespace_catalyst_1_1utf8.html", "namespace_catalyst_1_1utf8" ],
    [ "Constant", "struct_catalyst_1_1_constant.html", "struct_catalyst_1_1_constant" ],
    [ "csv", "class_catalyst_1_1csv.html", "class_catalyst_1_1csv" ],
    [ "Engine", "class_catalyst_1_1_engine.html", null ],
    [ "EventManager", "class_catalyst_1_1_event_manager.html", "class_catalyst_1_1_event_manager" ],
    [ "File", "struct_catalyst_1_1_file.html", "struct_catalyst_1_1_file" ],
    [ "Font", "class_catalyst_1_1_font.html", "class_catalyst_1_1_font" ],
    [ "IApplication", "class_catalyst_1_1_i_application.html", "class_catalyst_1_1_i_application" ],
    [ "IBaseEvent", "class_catalyst_1_1_i_base_event.html", "class_catalyst_1_1_i_base_event" ],
    [ "IBaseListener", "class_catalyst_1_1_i_base_listener.html", "class_catalyst_1_1_i_base_listener" ],
    [ "IEvent", "class_catalyst_1_1_i_event.html", "class_catalyst_1_1_i_event" ],
    [ "IFactory", "class_catalyst_1_1_i_factory.html", null ],
    [ "IFactoryShared", "class_catalyst_1_1_i_factory_shared.html", null ],
    [ "IListener", "class_catalyst_1_1_i_listener.html", null ],
    [ "IListener< Event >", "class_catalyst_1_1_i_listener_3_01_event_01_4.html", "class_catalyst_1_1_i_listener_3_01_event_01_4" ],
    [ "IListener< Event, Events... >", "class_catalyst_1_1_i_listener_3_01_event_00_01_events_8_8_8_01_4.html", "class_catalyst_1_1_i_listener_3_01_event_00_01_events_8_8_8_01_4" ],
    [ "Image", "class_catalyst_1_1_image.html", "class_catalyst_1_1_image" ],
    [ "IManager", "class_catalyst_1_1_i_manager.html", null ],
    [ "IManagerShared", "class_catalyst_1_1_i_manager_shared.html", null ],
    [ "IPipeline", "class_catalyst_1_1_i_pipeline.html", "class_catalyst_1_1_i_pipeline" ],
    [ "IRenderer", "class_catalyst_1_1_i_renderer.html", "class_catalyst_1_1_i_renderer" ],
    [ "ISurface", "class_catalyst_1_1_i_surface.html", "class_catalyst_1_1_i_surface" ],
    [ "ISwapChain", "class_catalyst_1_1_i_swap_chain.html", "class_catalyst_1_1_i_swap_chain" ],
    [ "json", "class_catalyst_1_1json.html", "class_catalyst_1_1json" ],
    [ "ListenerManager", "class_catalyst_1_1_listener_manager.html", "class_catalyst_1_1_listener_manager" ],
    [ "ListenerStorage", "class_catalyst_1_1_listener_storage.html", "class_catalyst_1_1_listener_storage" ],
    [ "Logger", "class_catalyst_1_1_logger.html", "class_catalyst_1_1_logger" ],
    [ "Path", "struct_catalyst_1_1_path.html", "struct_catalyst_1_1_path" ],
    [ "PipelineInformation", "struct_catalyst_1_1_pipeline_information.html", "struct_catalyst_1_1_pipeline_information" ],
    [ "Platform", "class_catalyst_1_1_platform.html", "class_catalyst_1_1_platform" ],
    [ "PlatformData", "struct_catalyst_1_1_platform_data.html", null ],
    [ "RendererInfo", "struct_catalyst_1_1_renderer_info.html", "struct_catalyst_1_1_renderer_info" ],
    [ "Scene", "class_catalyst_1_1_scene.html", "class_catalyst_1_1_scene" ],
    [ "SurfaceData", "struct_catalyst_1_1_surface_data.html", "struct_catalyst_1_1_surface_data" ],
    [ "Version", "struct_catalyst_1_1_version.html", null ],
    [ "WindowsPlatform", "class_catalyst_1_1_windows_platform.html", "class_catalyst_1_1_windows_platform" ],
    [ "WindowsSurface", "class_catalyst_1_1_windows_surface.html", "class_catalyst_1_1_windows_surface" ],
    [ "WindowsSurfaceData", "struct_catalyst_1_1_windows_surface_data.html", "struct_catalyst_1_1_windows_surface_data" ],
    [ "AssetManager", "namespace_catalyst.html#a46950f13fc71816f12da2267ba6223b9", null ],
    [ "catalyst_false", "namespace_catalyst.html#a1433898d7bcaee7e3ffe7652f9e8956e", null ],
    [ "catalyst_true", "namespace_catalyst.html#ac2063d13d721546ee0a6d4f8a63fec8a", null ],
    [ "CatalystBool", "namespace_catalyst.html#a010eba20088f9b0f10acb8e735febcb9", null ],
    [ "CatalystPtrRenderer", "namespace_catalyst.html#a28d5cd635e1a17363ce6d7b19c85962b", null ],
    [ "CatalystPtrSurface", "namespace_catalyst.html#a411e205138dfcaf618dbce8fbe5d3c82", null ],
    [ "createRnederer", "namespace_catalyst.html#a4ab4783b99fd43a96f08ca1e47a53772", null ],
    [ "DeviceID", "namespace_catalyst.html#ad00b956f60ff139a3a186e2baada9593", null ],
    [ "EventID", "namespace_catalyst.html#a9f3d890d2566e20eef4e83617f3380eb", null ],
    [ "EventType", "namespace_catalyst.html#a38d871681ba6ff4916919f483b436587", null ],
    [ "UChar", "namespace_catalyst.html#aecf3c6e93c218c9e73e5c4eabe3ab09b", null ],
    [ "CatalystArguments", "namespace_catalyst.html#a351df6ada83ba9941856b5f83453501e", [
      [ "PROFILE_LOCATION", "namespace_catalyst.html#a351df6ada83ba9941856b5f83453501ea2e6655565d9c97865c9958d66ec2210d", null ],
      [ "LOG_LOCATION", "namespace_catalyst.html#a351df6ada83ba9941856b5f83453501ea93461996edb2368c925bd1e6baeb1a0e", null ]
    ] ],
    [ "CatalystCullDirection", "namespace_catalyst.html#a20fbdead65751a941d727c512c7105d5", [
      [ "CATALYST_SHADER_CULL_DIRECTION_CLOCKWISE", "namespace_catalyst.html#a20fbdead65751a941d727c512c7105d5a5bab5afce878c05c9527830de9d5894b", null ],
      [ "CATALYST_SHADER_CULL_DIRECTION_COUNTER_CLOCKWISE", "namespace_catalyst.html#a20fbdead65751a941d727c512c7105d5a156d4f537e83ace8545389a22184bf15", null ]
    ] ],
    [ "CatalystCullFace", "namespace_catalyst.html#a5910c0992bdc7f48ddf3abf7471a5386", [
      [ "CATALYST_SHADER_CULL_FACE_FRONT", "namespace_catalyst.html#a5910c0992bdc7f48ddf3abf7471a5386af34bc85a2f6336576f58e74cec5a647a", null ],
      [ "CATALYST_SHADER_CULL_FACE_BACK", "namespace_catalyst.html#a5910c0992bdc7f48ddf3abf7471a5386ac49853fe89c8f7376a4774ac59db8e24", null ]
    ] ],
    [ "CatalystRendererFlags", "namespace_catalyst.html#ad98465b05d85fb047af7996825366cf5", [
      [ "CATALYST_RENDERER_FLAG_NONE", "namespace_catalyst.html#ad98465b05d85fb047af7996825366cf5a811c7683899e98e7e0c14d1858b1c754", null ],
      [ "CATALYST_RENDERER_FLAG_HEADLESS", "namespace_catalyst.html#ad98465b05d85fb047af7996825366cf5a4da9e5d79a8e426cf3de6be2af39873e", null ],
      [ "CATALYST_RENDERER_FLAG_DEVICE_DEFAULT", "namespace_catalyst.html#ad98465b05d85fb047af7996825366cf5a735cfc19adbfd113d36604fe23d9afae", null ],
      [ "CATALYST_RENDERER_FLAG_DEVICE_LOW_POWER", "namespace_catalyst.html#ad98465b05d85fb047af7996825366cf5a1110cbb7d2e3e22c9f7d7b3511ed577f", null ],
      [ "CATALYST_RENDERER_FLAG_DEVICE_INTEGERATED", "namespace_catalyst.html#ad98465b05d85fb047af7996825366cf5aaec6af582d5d1bdab788a5dbca718ec9", null ],
      [ "CATALYST_RENDERER_FLAG_SINGLE_BUFFER", "namespace_catalyst.html#ad98465b05d85fb047af7996825366cf5aee495014a64d6687df955ff1814a5e09", null ],
      [ "CATALYST_RENDERER_FLAG_DOUBLE_BUFFER", "namespace_catalyst.html#ad98465b05d85fb047af7996825366cf5a71170e5685e23a9fbd6383aa25143752", null ]
    ] ],
    [ "CatalystRendererType", "namespace_catalyst.html#a82afdd405b2006e7bdb107b41b4a230b", [
      [ "CATALYST_RENDERER_TYPE_NONE", "namespace_catalyst.html#a82afdd405b2006e7bdb107b41b4a230bab7f75ecf7fb010b44cdb456cb5892585", null ],
      [ "CATALYST_RENDERER_TYPE_VULKAN", "namespace_catalyst.html#a82afdd405b2006e7bdb107b41b4a230baede948fc2fd133eff73e8917fe1e825e", null ],
      [ "CATALYST_RENDERER_TYPE_DX11", "namespace_catalyst.html#a82afdd405b2006e7bdb107b41b4a230baeb8e39dfa79c3df15846a2ee24a3d6a8", null ],
      [ "CATALYST_RENDERER_TYPE_DX12", "namespace_catalyst.html#a82afdd405b2006e7bdb107b41b4a230ba73218eb7c32dfa4d6ca2e33c9586455f", null ]
    ] ],
    [ "CatalystShaderStageType", "namespace_catalyst.html#a099310c52593de4798f5b7e685dca9d2", [
      [ "CATALYST_SHADER_STAGE_UNKNOWN", "namespace_catalyst.html#a099310c52593de4798f5b7e685dca9d2a4b2330e01324e3a3a1e88da98446d90f", null ],
      [ "CATALYST_SHADER_STAGE_GEOMETERY", "namespace_catalyst.html#a099310c52593de4798f5b7e685dca9d2a9885e88441eeee3c351b5d4067a817f8", null ],
      [ "CATALYST_SHADER_STAGE_FRAGMENT", "namespace_catalyst.html#a099310c52593de4798f5b7e685dca9d2ad300a238c0949d2ac5aaa7f6f885d9d0", null ],
      [ "CATALYST_SHADER_STAGE_TESSELATION", "namespace_catalyst.html#a099310c52593de4798f5b7e685dca9d2ab6c8eeb8f3ed6757282de81081d76a65", null ]
    ] ],
    [ "CatalystShaderTopology", "namespace_catalyst.html#a9ba83b9c991bd86a3b6e98b31b68a275", [
      [ "CATALYST_SHADER_TOPOLOGY_POINT_LIST", "namespace_catalyst.html#a9ba83b9c991bd86a3b6e98b31b68a275aee5c92ed4be58c8a82b9876f7e8b8343", null ],
      [ "CATALYST_SHADER_TOPOLOGY_LINE_LIST", "namespace_catalyst.html#a9ba83b9c991bd86a3b6e98b31b68a275ae0471fb25cd4c73bd5145906893cbf87", null ],
      [ "CATALYST_SHADER_TOPOLOGY_LINE_STRIP", "namespace_catalyst.html#a9ba83b9c991bd86a3b6e98b31b68a275aa450b6bd0423d7f151108b26e28aa145", null ],
      [ "CATALYST_SHADER_TOPOLOGY_TRIANGLE_FAN", "namespace_catalyst.html#a9ba83b9c991bd86a3b6e98b31b68a275a725211c447ac576b016e5d1a997c1d60", null ],
      [ "CATALYST_SHADER_TOPOLOGY_TRIANGLE_LIST", "namespace_catalyst.html#a9ba83b9c991bd86a3b6e98b31b68a275af0e7034f12f71598a85d9aa1240e554d", null ],
      [ "CATALYST_SHADER_TOPOLOGY_TRIANGLE_STRIP", "namespace_catalyst.html#a9ba83b9c991bd86a3b6e98b31b68a275abe076996041e84e6385d72343da3b952", null ]
    ] ],
    [ "CatalystSurfaceFlags", "namespace_catalyst.html#abbe882740464284621241b0e65b8fecc", [
      [ "CATALYST_SURFACE_DEFAULT_POSITION", "namespace_catalyst.html#abbe882740464284621241b0e65b8fecca52c3d67c227dc8f9a8a88c82aadda535", null ],
      [ "CATALYST_SURFACE_DEFAULT_DIMENSION", "namespace_catalyst.html#abbe882740464284621241b0e65b8fecca97427ef6b6e396bd0a5d45bb23cb6ae6", null ]
    ] ],
    [ "Openmode", "namespace_catalyst.html#a60e9abc5fd86e9a77af4909bfa48ba76", [
      [ "app", "namespace_catalyst.html#a60e9abc5fd86e9a77af4909bfa48ba76ad2a57dc1d883fd21fb9951699df71cc7", null ],
      [ "in", "namespace_catalyst.html#a60e9abc5fd86e9a77af4909bfa48ba76a13b5bfe96f3e2fe411c9f66f4a582adf", null ],
      [ "out", "namespace_catalyst.html#a60e9abc5fd86e9a77af4909bfa48ba76ac68271a63ddbc431c307beb7d2918275", null ],
      [ "ate", "namespace_catalyst.html#a60e9abc5fd86e9a77af4909bfa48ba76a1f0cec14e2c5effcbff50f2feb9495f6", null ],
      [ "trunc", "namespace_catalyst.html#a60e9abc5fd86e9a77af4909bfa48ba76ade5010661a527a7f3565e98f672eb896", null ],
      [ "nocreate", "namespace_catalyst.html#a60e9abc5fd86e9a77af4909bfa48ba76a5fbb06bfe5b864fbcc300b6d4a393fc7", null ],
      [ "noreplace", "namespace_catalyst.html#a60e9abc5fd86e9a77af4909bfa48ba76a12e6b8ef04a12c5eb0069e1bee66cf9b", null ],
      [ "binary", "namespace_catalyst.html#a60e9abc5fd86e9a77af4909bfa48ba76a9d7183f16acce70658f686ae7f1a4d20", null ]
    ] ],
    [ "CatalystFindMatch", "namespace_catalyst.html#ae71d34e709f9956c98c76be90c04da20", null ],
    [ "CatalystLaunch", "namespace_catalyst.html#ac9a31394354fbd98ad598fc53d23ac5f", null ],
    [ "CatalystSplitString", "namespace_catalyst.html#a1350bc036a9f83d95c305135a95e4f6d", null ],
    [ "for_each", "namespace_catalyst.html#a3b705c394e32ffa19d5c02adca586022", null ],
    [ "for_each", "namespace_catalyst.html#aea07613d046cb48d1dc0cec651dcb742", null ],
    [ "for_each", "namespace_catalyst.html#a129cbb73ffb65d32ca956d41042b272b", null ],
    [ "initalizePlatform", "namespace_catalyst.html#a43172a69dca3e4030c097785180da212", null ],
    [ "catalystArguments", "namespace_catalyst.html#aa727a0bfc5d4e887e50ee8f4f8966e44", null ],
    [ "m_Scene", "namespace_catalyst.html#ab3c589928b23b04e68d6a012d869cdf2", null ]
];