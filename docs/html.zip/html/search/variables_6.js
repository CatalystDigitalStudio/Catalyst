var searchData=
[
  ['patch_0',['patch',['../struct_catalyst_1_1_version.html#a4205a87639e93233e835143f9e347426',1,'Catalyst::Version']]]
];
