var namespaces_dup =
[
    [ "Catalyst", "namespace_catalyst.html", "namespace_catalyst" ]
];