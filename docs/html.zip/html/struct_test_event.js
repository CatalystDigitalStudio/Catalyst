var struct_test_event =
[
    [ "TestEvent", "struct_test_event.html#a3c14aa9a12dd29aa66e8fd92a957fad7", null ],
    [ "i", "struct_test_event.html#a8d06f42525ccfd87ab192a11ee12f581", null ]
];