var class_catalyst_1_1_i_base_event =
[
    [ "getID", "class_catalyst_1_1_i_base_event.html#ace02f634ae5b96a4fe2aea068f3e4959", null ],
    [ "getType", "class_catalyst_1_1_i_base_event.html#ab2e232f651729b5345ab901f18a4543d", null ],
    [ "ID", "class_catalyst_1_1_i_base_event.html#a7326c6ee1d6ce0b0b8932ef22e10f4a6", null ]
];