var struct_test_scene =
[
    [ "TestScene", "struct_test_scene.html#a10627e64e9b5460342330aa6111f5f12", null ],
    [ "~TestScene", "struct_test_scene.html#a38c197dd9aa8c436824417907113592a", null ],
    [ "onCreate", "struct_test_scene.html#ae9c9648ba24133765e81de432754a127", null ],
    [ "onDestroy", "struct_test_scene.html#a02a8e7097bf4c607e95d58ba2ba8a183", null ],
    [ "onUpdate", "struct_test_scene.html#aaf647bd954fcefabb2fa2909ae5d6de7", null ]
];