var struct_catalyst_1_1_windows_surface_data =
[
    [ "m_Message", "struct_catalyst_1_1_windows_surface_data.html#a1c70e7ab0bf26149da8ef408d1550531", null ],
    [ "m_Window", "struct_catalyst_1_1_windows_surface_data.html#aa49c3da93996661135ceaee8294fb29f", null ]
];