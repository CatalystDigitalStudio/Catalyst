var struct_catalyst_1_1_path =
[
    [ "m_Extention", "struct_catalyst_1_1_path.html#a3510856a3b561595e39a5efe31faab09", null ],
    [ "m_FullPath", "struct_catalyst_1_1_path.html#a8b83d050bb183207d4734d89f4396e23", null ],
    [ "m_Name", "struct_catalyst_1_1_path.html#a08ae28d8d0270d5e43e21018f3972475", null ],
    [ "m_Path", "struct_catalyst_1_1_path.html#a4b85a37d59b45baabf43d3b8bc342237", null ]
];