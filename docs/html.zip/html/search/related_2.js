var searchData=
[
  ['ifactory_0',['IFactory',['../struct_catalyst_1_1_file.html#a13da02d6308a949405648cc28f1b4172',1,'Catalyst::File::IFactory()'],['../class_catalyst_1_1_image.html#a13da02d6308a949405648cc28f1b4172',1,'Catalyst::Image::IFactory()']]]
];
