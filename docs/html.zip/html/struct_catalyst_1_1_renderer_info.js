var struct_catalyst_1_1_renderer_info =
[
    [ "flags", "struct_catalyst_1_1_renderer_info.html#a33a01975cb7d2340ebce02090661c4f1", null ],
    [ "type", "struct_catalyst_1_1_renderer_info.html#a25a493b4f1a689072e1b89b2e7967416", null ]
];