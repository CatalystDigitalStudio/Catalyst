var renderer_8h =
[
    [ "Catalyst::PipelineInformation", "struct_catalyst_1_1_pipeline_information.html", "struct_catalyst_1_1_pipeline_information" ],
    [ "Catalyst::IPipeline", "class_catalyst_1_1_i_pipeline.html", "class_catalyst_1_1_i_pipeline" ],
    [ "Catalyst::ISwapChain", "class_catalyst_1_1_i_swap_chain.html", "class_catalyst_1_1_i_swap_chain" ],
    [ "Catalyst::RendererInfo", "struct_catalyst_1_1_renderer_info.html", "struct_catalyst_1_1_renderer_info" ],
    [ "Catalyst::IRenderer", "class_catalyst_1_1_i_renderer.html", "class_catalyst_1_1_i_renderer" ],
    [ "CatalystPtrRenderer", "renderer_8h.html#a28d5cd635e1a17363ce6d7b19c85962b", null ],
    [ "DeviceID", "renderer_8h.html#ad00b956f60ff139a3a186e2baada9593", null ],
    [ "CatalystCullDirection", "renderer_8h.html#a20fbdead65751a941d727c512c7105d5", [
      [ "CATALYST_SHADER_CULL_DIRECTION_CLOCKWISE", "renderer_8h.html#a20fbdead65751a941d727c512c7105d5a5bab5afce878c05c9527830de9d5894b", null ],
      [ "CATALYST_SHADER_CULL_DIRECTION_COUNTER_CLOCKWISE", "renderer_8h.html#a20fbdead65751a941d727c512c7105d5a156d4f537e83ace8545389a22184bf15", null ]
    ] ],
    [ "CatalystCullFace", "renderer_8h.html#a5910c0992bdc7f48ddf3abf7471a5386", [
      [ "CATALYST_SHADER_CULL_FACE_FRONT", "renderer_8h.html#a5910c0992bdc7f48ddf3abf7471a5386af34bc85a2f6336576f58e74cec5a647a", null ],
      [ "CATALYST_SHADER_CULL_FACE_BACK", "renderer_8h.html#a5910c0992bdc7f48ddf3abf7471a5386ac49853fe89c8f7376a4774ac59db8e24", null ]
    ] ],
    [ "CatalystRendererFlags", "renderer_8h.html#ad98465b05d85fb047af7996825366cf5", [
      [ "CATALYST_RENDERER_FLAG_NONE", "renderer_8h.html#ad98465b05d85fb047af7996825366cf5a811c7683899e98e7e0c14d1858b1c754", null ],
      [ "CATALYST_RENDERER_FLAG_HEADLESS", "renderer_8h.html#ad98465b05d85fb047af7996825366cf5a4da9e5d79a8e426cf3de6be2af39873e", null ],
      [ "CATALYST_RENDERER_FLAG_DEVICE_DEFAULT", "renderer_8h.html#ad98465b05d85fb047af7996825366cf5a735cfc19adbfd113d36604fe23d9afae", null ],
      [ "CATALYST_RENDERER_FLAG_DEVICE_LOW_POWER", "renderer_8h.html#ad98465b05d85fb047af7996825366cf5a1110cbb7d2e3e22c9f7d7b3511ed577f", null ],
      [ "CATALYST_RENDERER_FLAG_DEVICE_INTEGERATED", "renderer_8h.html#ad98465b05d85fb047af7996825366cf5aaec6af582d5d1bdab788a5dbca718ec9", null ],
      [ "CATALYST_RENDERER_FLAG_SINGLE_BUFFER", "renderer_8h.html#ad98465b05d85fb047af7996825366cf5aee495014a64d6687df955ff1814a5e09", null ],
      [ "CATALYST_RENDERER_FLAG_DOUBLE_BUFFER", "renderer_8h.html#ad98465b05d85fb047af7996825366cf5a71170e5685e23a9fbd6383aa25143752", null ]
    ] ],
    [ "CatalystRendererType", "renderer_8h.html#a82afdd405b2006e7bdb107b41b4a230b", [
      [ "CATALYST_RENDERER_TYPE_NONE", "renderer_8h.html#a82afdd405b2006e7bdb107b41b4a230bab7f75ecf7fb010b44cdb456cb5892585", null ],
      [ "CATALYST_RENDERER_TYPE_VULKAN", "renderer_8h.html#a82afdd405b2006e7bdb107b41b4a230baede948fc2fd133eff73e8917fe1e825e", null ],
      [ "CATALYST_RENDERER_TYPE_DX11", "renderer_8h.html#a82afdd405b2006e7bdb107b41b4a230baeb8e39dfa79c3df15846a2ee24a3d6a8", null ],
      [ "CATALYST_RENDERER_TYPE_DX12", "renderer_8h.html#a82afdd405b2006e7bdb107b41b4a230ba73218eb7c32dfa4d6ca2e33c9586455f", null ]
    ] ],
    [ "CatalystShaderStageType", "renderer_8h.html#a099310c52593de4798f5b7e685dca9d2", [
      [ "CATALYST_SHADER_STAGE_UNKNOWN", "renderer_8h.html#a099310c52593de4798f5b7e685dca9d2a4b2330e01324e3a3a1e88da98446d90f", null ],
      [ "CATALYST_SHADER_STAGE_GEOMETERY", "renderer_8h.html#a099310c52593de4798f5b7e685dca9d2a9885e88441eeee3c351b5d4067a817f8", null ],
      [ "CATALYST_SHADER_STAGE_FRAGMENT", "renderer_8h.html#a099310c52593de4798f5b7e685dca9d2ad300a238c0949d2ac5aaa7f6f885d9d0", null ],
      [ "CATALYST_SHADER_STAGE_TESSELATION", "renderer_8h.html#a099310c52593de4798f5b7e685dca9d2ab6c8eeb8f3ed6757282de81081d76a65", null ]
    ] ],
    [ "CatalystShaderTopology", "renderer_8h.html#a9ba83b9c991bd86a3b6e98b31b68a275", [
      [ "CATALYST_SHADER_TOPOLOGY_POINT_LIST", "renderer_8h.html#a9ba83b9c991bd86a3b6e98b31b68a275aee5c92ed4be58c8a82b9876f7e8b8343", null ],
      [ "CATALYST_SHADER_TOPOLOGY_LINE_LIST", "renderer_8h.html#a9ba83b9c991bd86a3b6e98b31b68a275ae0471fb25cd4c73bd5145906893cbf87", null ],
      [ "CATALYST_SHADER_TOPOLOGY_LINE_STRIP", "renderer_8h.html#a9ba83b9c991bd86a3b6e98b31b68a275aa450b6bd0423d7f151108b26e28aa145", null ],
      [ "CATALYST_SHADER_TOPOLOGY_TRIANGLE_FAN", "renderer_8h.html#a9ba83b9c991bd86a3b6e98b31b68a275a725211c447ac576b016e5d1a997c1d60", null ],
      [ "CATALYST_SHADER_TOPOLOGY_TRIANGLE_LIST", "renderer_8h.html#a9ba83b9c991bd86a3b6e98b31b68a275af0e7034f12f71598a85d9aa1240e554d", null ],
      [ "CATALYST_SHADER_TOPOLOGY_TRIANGLE_STRIP", "renderer_8h.html#a9ba83b9c991bd86a3b6e98b31b68a275abe076996041e84e6385d72343da3b952", null ]
    ] ]
];