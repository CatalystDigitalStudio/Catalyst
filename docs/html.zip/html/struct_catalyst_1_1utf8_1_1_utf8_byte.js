var struct_catalyst_1_1utf8_1_1_utf8_byte =
[
    [ "bit0", "struct_catalyst_1_1utf8_1_1_utf8_byte.html#ad1e8e19b9c5fa156e56da5e5ef709a7e", null ],
    [ "bit1", "struct_catalyst_1_1utf8_1_1_utf8_byte.html#a6bd9892b3125dfd75b3a64b0d144f6d6", null ],
    [ "bit2", "struct_catalyst_1_1utf8_1_1_utf8_byte.html#aef3ac1d08e6a7769a467deaf2455eca7", null ],
    [ "bit3", "struct_catalyst_1_1utf8_1_1_utf8_byte.html#a1522b75a513a8b0e33b2c5d9f7c060ac", null ],
    [ "bit4", "struct_catalyst_1_1utf8_1_1_utf8_byte.html#ac2a3736c315200bd90103849a13194d3", null ],
    [ "bit5", "struct_catalyst_1_1utf8_1_1_utf8_byte.html#ae28aa9597986e668fb3128d901ec519c", null ],
    [ "bit6", "struct_catalyst_1_1utf8_1_1_utf8_byte.html#a843f1ca6346e2ecba5c759e4fa650d49", null ],
    [ "bit7", "struct_catalyst_1_1utf8_1_1_utf8_byte.html#affbeab2f3b8774e235a2554004e47e9d", null ]
];