var class_catalyst_1_1_i_swap_chain =
[
    [ "~ISwapChain", "class_catalyst_1_1_i_swap_chain.html#adeed5064afd14cb35b1fdf2de508e6cf", null ],
    [ "initalize", "class_catalyst_1_1_i_swap_chain.html#a9a967e10264c517f0a088f57f23c8ad8", null ]
];