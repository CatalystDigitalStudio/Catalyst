var searchData=
[
  ['s_5fdata_0',['s_Data',['../class_catalyst_1_1_i_manager.html#ab1726f5c60dbf4c9c184b0bc6657c3b8',1,'Catalyst::IManager::s_Data()'],['../class_catalyst_1_1_i_manager_shared.html#a0c77ec56e687adbb42456b506e526267',1,'Catalyst::IManagerShared::s_Data()']]]
];
