var class_catalyst_1_1_platform =
[
    [ "createRenderer", "class_catalyst_1_1_platform.html#a45f98666fe4344c0d2ea6c96d0fe5260", null ],
    [ "createSurface", "class_catalyst_1_1_platform.html#a312e78c4a6b253424163239347775019", null ],
    [ "getPlatformData", "class_catalyst_1_1_platform.html#a2913ab6660edcdf1eb511320eb11818c", null ]
];