var unicode_8cpp =
[
    [ "createNodeList", "unicode_8cpp.html#a83407972ffea9b093f226d172eb82605", null ],
    [ "decodeCodepoint", "unicode_8cpp.html#ae27f71b8ee3cd72f46c53139e21044ab", null ],
    [ "encodeCodepoint", "unicode_8cpp.html#a5e2db1446afe2788a261f739bc4ff05f", null ],
    [ "nextCodepointLength", "unicode_8cpp.html#a9bd46aea613bba6e56bfdea1f36e45be", null ]
];