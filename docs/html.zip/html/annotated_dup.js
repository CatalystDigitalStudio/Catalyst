var annotated_dup =
[
    [ "Catalyst", "namespace_catalyst.html", [
      [ "file", "namespace_catalyst_1_1file.html", [
        [ "CSVFile", "class_catalyst_1_1file_1_1_c_s_v_file.html", null ],
        [ "JSONMultiLangFile", "class_catalyst_1_1file_1_1_j_s_o_n_multi_lang_file.html", "class_catalyst_1_1file_1_1_j_s_o_n_multi_lang_file" ]
      ] ],
      [ "unicode", "namespace_catalyst_1_1unicode.html", [
        [ "Node", "struct_catalyst_1_1unicode_1_1_node.html", "struct_catalyst_1_1unicode_1_1_node" ],
        [ "UtfAllocationSection", "struct_catalyst_1_1unicode_1_1_utf_allocation_section.html", null ]
      ] ],
      [ "utf8", "namespace_catalyst_1_1utf8.html", [
        [ "Utf8Byte", "struct_catalyst_1_1utf8_1_1_utf8_byte.html", "struct_catalyst_1_1utf8_1_1_utf8_byte" ]
      ] ],
      [ "Constant", "struct_catalyst_1_1_constant.html", "struct_catalyst_1_1_constant" ],
      [ "csv", "class_catalyst_1_1csv.html", "class_catalyst_1_1csv" ],
      [ "Engine", "class_catalyst_1_1_engine.html", null ],
      [ "EventManager", "class_catalyst_1_1_event_manager.html", "class_catalyst_1_1_event_manager" ],
      [ "File", "struct_catalyst_1_1_file.html", "struct_catalyst_1_1_file" ],
      [ "Font", "class_catalyst_1_1_font.html", "class_catalyst_1_1_font" ],
      [ "IApplication", "class_catalyst_1_1_i_application.html", "class_catalyst_1_1_i_application" ],
      [ "IBaseEvent", "class_catalyst_1_1_i_base_event.html", "class_catalyst_1_1_i_base_event" ],
      [ "IBaseListener", "class_catalyst_1_1_i_base_listener.html", "class_catalyst_1_1_i_base_listener" ],
      [ "IEvent", "class_catalyst_1_1_i_event.html", "class_catalyst_1_1_i_event" ],
      [ "IFactory", "class_catalyst_1_1_i_factory.html", null ],
      [ "IFactoryShared", "class_catalyst_1_1_i_factory_shared.html", null ],
      [ "IListener", "class_catalyst_1_1_i_listener.html", null ],
      [ "IListener< Event >", "class_catalyst_1_1_i_listener_3_01_event_01_4.html", "class_catalyst_1_1_i_listener_3_01_event_01_4" ],
      [ "IListener< Event, Events... >", "class_catalyst_1_1_i_listener_3_01_event_00_01_events_8_8_8_01_4.html", "class_catalyst_1_1_i_listener_3_01_event_00_01_events_8_8_8_01_4" ],
      [ "Image", "class_catalyst_1_1_image.html", "class_catalyst_1_1_image" ],
      [ "IManager", "class_catalyst_1_1_i_manager.html", null ],
      [ "IManagerShared", "class_catalyst_1_1_i_manager_shared.html", null ],
      [ "IPipeline", "class_catalyst_1_1_i_pipeline.html", "class_catalyst_1_1_i_pipeline" ],
      [ "IRenderer", "class_catalyst_1_1_i_renderer.html", "class_catalyst_1_1_i_renderer" ],
      [ "ISurface", "class_catalyst_1_1_i_surface.html", "class_catalyst_1_1_i_surface" ],
      [ "ISwapChain", "class_catalyst_1_1_i_swap_chain.html", "class_catalyst_1_1_i_swap_chain" ],
      [ "json", "class_catalyst_1_1json.html", "class_catalyst_1_1json" ],
      [ "ListenerManager", "class_catalyst_1_1_listener_manager.html", "class_catalyst_1_1_listener_manager" ],
      [ "ListenerStorage", "class_catalyst_1_1_listener_storage.html", "class_catalyst_1_1_listener_storage" ],
      [ "Logger", "class_catalyst_1_1_logger.html", "class_catalyst_1_1_logger" ],
      [ "Path", "struct_catalyst_1_1_path.html", "struct_catalyst_1_1_path" ],
      [ "PipelineInformation", "struct_catalyst_1_1_pipeline_information.html", "struct_catalyst_1_1_pipeline_information" ],
      [ "Platform", "class_catalyst_1_1_platform.html", "class_catalyst_1_1_platform" ],
      [ "PlatformData", "struct_catalyst_1_1_platform_data.html", null ],
      [ "RendererInfo", "struct_catalyst_1_1_renderer_info.html", "struct_catalyst_1_1_renderer_info" ],
      [ "Scene", "class_catalyst_1_1_scene.html", "class_catalyst_1_1_scene" ],
      [ "SurfaceData", "struct_catalyst_1_1_surface_data.html", "struct_catalyst_1_1_surface_data" ],
      [ "Version", "struct_catalyst_1_1_version.html", null ],
      [ "WindowsPlatform", "class_catalyst_1_1_windows_platform.html", "class_catalyst_1_1_windows_platform" ],
      [ "WindowsSurface", "class_catalyst_1_1_windows_surface.html", "class_catalyst_1_1_windows_surface" ],
      [ "WindowsSurfaceData", "struct_catalyst_1_1_windows_surface_data.html", "struct_catalyst_1_1_windows_surface_data" ]
    ] ],
    [ "DX11Device", "class_d_x11_device.html", "class_d_x11_device" ],
    [ "DX11Renderer", "class_d_x11_renderer.html", "class_d_x11_renderer" ],
    [ "ListenerFunction", "class_listener_function.html", null ],
    [ "Reactor", "class_reactor.html", "class_reactor" ],
    [ "TestEvent", "struct_test_event.html", "struct_test_event" ],
    [ "TestScene", "struct_test_scene.html", "struct_test_scene" ],
    [ "VulkanImage", "struct_vulkan_image.html", "struct_vulkan_image" ],
    [ "VulkanPipeline", "class_vulkan_pipeline.html", "class_vulkan_pipeline" ],
    [ "VulkanRenderer", "class_vulkan_renderer.html", "class_vulkan_renderer" ]
];