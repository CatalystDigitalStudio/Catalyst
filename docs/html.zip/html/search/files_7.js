var searchData=
[
  ['manager_2eh_0',['manager.h',['../manager_8h.html',1,'']]]
];
