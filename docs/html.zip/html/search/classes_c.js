var searchData=
[
  ['utf8byte_0',['Utf8Byte',['../struct_catalyst_1_1utf8_1_1_utf8_byte.html',1,'Catalyst::utf8']]],
  ['utfallocationsection_1',['UtfAllocationSection',['../struct_catalyst_1_1unicode_1_1_utf_allocation_section.html',1,'Catalyst::unicode']]]
];
