var struct_catalyst_1_1unicode_1_1_node =
[
    [ "m_Data", "struct_catalyst_1_1unicode_1_1_node.html#a5546af27df236a9328610892aac4ee34", null ],
    [ "m_Next", "struct_catalyst_1_1unicode_1_1_node.html#a637604e8c44b64e1fcdb30c71f45c783", null ],
    [ "m_Parent", "struct_catalyst_1_1unicode_1_1_node.html#a0267f2a9f8d3167ffa5f2bd4e7f1cdb9", null ],
    [ "m_Previous", "struct_catalyst_1_1unicode_1_1_node.html#a5e856088e03b5fb27c60947539beb331", null ]
];