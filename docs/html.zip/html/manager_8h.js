var manager_8h =
[
    [ "Catalyst::IManager< Key, Value >", "class_catalyst_1_1_i_manager.html", null ],
    [ "Catalyst::IManagerShared< Key, Value >", "class_catalyst_1_1_i_manager_shared.html", null ]
];